﻿
namespace _32368984_Prakties11_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblVerblyf = new System.Windows.Forms.Label();
            this.lblMeals = new System.Windows.Forms.Label();
            this.lbVerblyf = new System.Windows.Forms.ListBox();
            this.lbMeal = new System.Windows.Forms.ListBox();
            this.btnDisplay = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblVerblyf
            // 
            this.lblVerblyf.AutoSize = true;
            this.lblVerblyf.Location = new System.Drawing.Point(44, 62);
            this.lblVerblyf.Name = "lblVerblyf";
            this.lblVerblyf.Size = new System.Drawing.Size(51, 13);
            this.lblVerblyf.TabIndex = 0;
            this.lblVerblyf.Text = "Domitory:";
            // 
            // lblMeals
            // 
            this.lblMeals.AutoSize = true;
            this.lblMeals.Location = new System.Drawing.Point(209, 62);
            this.lblMeals.Name = "lblMeals";
            this.lblMeals.Size = new System.Drawing.Size(57, 13);
            this.lblMeals.TabIndex = 1;
            this.lblMeals.Text = "Meal Plan:";
            // 
            // lbVerblyf
            // 
            this.lbVerblyf.FormattingEnabled = true;
            this.lbVerblyf.Items.AddRange(new object[] {
            "Allan Hall",
            "Pike Hall",
            "Farthing Hall",
            "University Suites"});
            this.lbVerblyf.Location = new System.Drawing.Point(47, 78);
            this.lbVerblyf.Name = "lbVerblyf";
            this.lbVerblyf.Size = new System.Drawing.Size(120, 95);
            this.lbVerblyf.TabIndex = 2;
            // 
            // lbMeal
            // 
            this.lbMeal.FormattingEnabled = true;
            this.lbMeal.Items.AddRange(new object[] {
            "7 meals per week",
            "14 meals per week",
            "Unlimited meals"});
            this.lbMeal.Location = new System.Drawing.Point(212, 78);
            this.lbMeal.Name = "lbMeal";
            this.lbMeal.Size = new System.Drawing.Size(120, 95);
            this.lbMeal.TabIndex = 3;
            // 
            // btnDisplay
            // 
            this.btnDisplay.Location = new System.Drawing.Point(257, 192);
            this.btnDisplay.Name = "btnDisplay";
            this.btnDisplay.Size = new System.Drawing.Size(75, 23);
            this.btnDisplay.TabIndex = 4;
            this.btnDisplay.Text = "Display";
            this.btnDisplay.UseVisualStyleBackColor = true;
            this.btnDisplay.Click += new System.EventHandler(this.btnDisplay_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(351, 311);
            this.Controls.Add(this.btnDisplay);
            this.Controls.Add(this.lbMeal);
            this.Controls.Add(this.lbVerblyf);
            this.Controls.Add(this.lblMeals);
            this.Controls.Add(this.lblVerblyf);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblVerblyf;
        private System.Windows.Forms.Label lblMeals;
        private System.Windows.Forms.ListBox lbVerblyf;
        private System.Windows.Forms.ListBox lbMeal;
        private System.Windows.Forms.Button btnDisplay;
    }
}

