﻿
namespace _32368984_Prakties11_1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblDormitory = new System.Windows.Forms.Label();
            this.lblMealPlan = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblDormitory
            // 
            this.lblDormitory.AutoSize = true;
            this.lblDormitory.Location = new System.Drawing.Point(12, 9);
            this.lblDormitory.Name = "lblDormitory";
            this.lblDormitory.Size = new System.Drawing.Size(35, 13);
            this.lblDormitory.TabIndex = 0;
            this.lblDormitory.Text = "label1";
            // 
            // lblMealPlan
            // 
            this.lblMealPlan.AutoSize = true;
            this.lblMealPlan.Location = new System.Drawing.Point(12, 36);
            this.lblMealPlan.Name = "lblMealPlan";
            this.lblMealPlan.Size = new System.Drawing.Size(35, 13);
            this.lblMealPlan.TabIndex = 1;
            this.lblMealPlan.Text = "label2";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(12, 62);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(35, 13);
            this.lblTotal.TabIndex = 2;
            this.lblTotal.Text = "label3";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 271);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.lblMealPlan);
            this.Controls.Add(this.lblDormitory);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lblDormitory;
        public System.Windows.Forms.Label lblMealPlan;
        public System.Windows.Forms.Label lblTotal;
    }
}