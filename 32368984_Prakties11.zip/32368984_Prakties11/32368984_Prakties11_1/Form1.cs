﻿//Kevin-Peter Naude     32368984
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _32368984_Prakties11_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {//verklaar veranderlikes
            string verblyf, kos;
            double verblyfKoste = 0, kosKostes = 0;
            //verkry die waardes vir die switch statments
            verblyf = lbVerblyf.SelectedIndex.ToString();
            kos = lbMeal.SelectedIndex.ToString();

            switch(verblyf)
            {
                case "0"://Allan Hall
                    {
                        
                        verblyfKoste = 1500;//koste vir Allan Hall
                        break;
                    }

                case "1"://Pike Hall
                    {
                        
                        verblyfKoste = 1600;//koste vir Pike Hall
                        break;
                    }

                case "2"://Farthing Hall
                    {
                        
                        verblyfKoste = 1800;// koste vir Farthing Hall
                        break;
                    }

                case "3"://University Suites
                    {
                        
                        verblyfKoste = 2500;// koste vir University Suites
                        break;
                    }

                default:
                    {
                        MessageBox.Show("No House Selected");//vertoon fout boodskap
                        break;
                    }
            }

            switch (kos)
            {
                case "0"://7 meals per week
                    {

                        kosKostes = 600;//koste vir meals
                        break;
                    }

                case "1"://14 meals per week
                    {

                        kosKostes = 1200;//koste vir meals
                        break;
                    }

                case "2"://Unlimited meals
                    {

                        kosKostes = 1700;//koste vir meals
                        break;
                    }

                default:
                    {
                        MessageBox.Show("No Meal Plan selected");//vertoon fout boodskap
                        break;
                    }

            }
            double total = verblyfKoste + kosKostes;// werk die totale koste uit
            Form2 myform2 = new Form2();//verklaar form 2
            myform2.lblDormitory.Text = "Dormitory: " + verblyfKoste.ToString("C") + " per semester";//afvoer
            myform2.lblMealPlan.Text = "Meal Plan " + kosKostes.ToString("C") + " per semester";//afvoer
            myform2.lblTotal.Text = "Total: " + total.ToString("C");//afvoer
            myform2.ShowDialog();//vertoon from 2


            
        }
    }
}
