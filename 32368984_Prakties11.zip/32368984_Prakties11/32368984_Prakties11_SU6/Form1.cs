﻿//Kevin-Peter Naude     32368984
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _32368984_Prakties11_SU6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {//verklaar veranderlikes
            string name, bank = "";
            double amount, total = 0;
            //gee waard aan name
            name = tbName.Text;
            //kyk of die verbruiker die regte data tipe in gelees het
            if(double.TryParse(tbAmount.Text, out amount))
            {
                if(rbtnFin.Checked)//kyk watter bank die gebruiker gekies het
                {
                    bank = "Fin Bank";//die bank se naam
                    total = calculateTotal(amount, 1.02);//gebruik die funksie
                }
                else if(rbtnABC.Checked)//kyk watter bank die gebruiker gekies het
                {
                    bank = "ABC Bank";//die bank se naam
                    total = calculateTotal(amount, 1.05);//gebruik die funksie
                }
                else
                {
                    MessageBox.Show("No Bank Selected");//vertoon fout boodskap
                    rbtnFin.Focus();//fokus op die radioButton
                }
                Display(name, amount, bank, total);//gebruik die funksie

            }
            else
            {
                MessageBox.Show("Invalid Input!");//vertoon die fout boodskap
                tbAmount.Focus();//fokus op tbAmount
            }

            
     
        }


        private void Display(string name, double amount, string bank, double total)
        {
            Form2 myform2 = new Form2();//maak form 2 beskikbaar om te gebruik
            myform2.lbAfvoer.Items.Add("Name of Client: " + name);//afvoer op form 2
            myform2.lbAfvoer.Items.Add("The amount you bank: " + amount.ToString("C"));//afvoer op form 2
            myform2.lbAfvoer.Items.Add("The bank you Selected:" + bank);//afvoer op form 2
            myform2.lbAfvoer.Items.Add("The total of the amount you banked over a month: " + total.ToString("C"));//afvoer op form 2
            myform2.ShowDialog();//wys form 2
        }

        private double calculateTotal(double amount, double presentage)
        {
            double total;//verklaar veranderlike
            total = amount * presentage;//maak die som
            return total;//return na form1
        }

    }
}
