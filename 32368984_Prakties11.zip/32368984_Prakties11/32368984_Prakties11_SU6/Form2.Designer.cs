﻿
namespace _32368984_Prakties11_SU6
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbAfvoer = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lbAfvoer
            // 
            this.lbAfvoer.FormattingEnabled = true;
            this.lbAfvoer.Location = new System.Drawing.Point(12, 12);
            this.lbAfvoer.Name = "lbAfvoer";
            this.lbAfvoer.Size = new System.Drawing.Size(456, 173);
            this.lbAfvoer.TabIndex = 0;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 219);
            this.Controls.Add(this.lbAfvoer);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.ListBox lbAfvoer;
    }
}