﻿//Kevin-Peter Naude     32368984
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _32368984_Prakties10_6_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // maak die teks bokse skoon
            tbStay.Text = "";
            tbRestaurant.Text = "";
            tbTreat.Text = "";
            tbRental.Text = "";
            tbMaR.Text = "";
            //maak list boks skoon
            lbAfvoer.Items.Clear();
            // Fokus op eerste textBoxes
            tbStay.Focus();

            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCal_Click(object sender, EventArgs e)
        {   // verklaar vertanderlikes
            int stay;
            double kos, treat, rent, med, verblyf, extras, total;

            if (int.TryParse(tbStay.Text, out stay))
            {
                if(double.TryParse(tbRestaurant.Text, out kos))
                {
                    if(double.TryParse(tbTreat.Text, out treat))
                    {
                        if(double.TryParse(tbRental.Text, out rent))
                        {
                            if(double.TryParse(tbMaR.Text, out med))
                            {
                                verblyf = CalcStayCharges(stay);//gebruik funksie en verkry waarde

                                extras = CalcMiscCharges(kos, treat, rent, med);//gebruik funksie en verkry waarde
                                
                                total = CalcTotalCharges(verblyf, extras);//gebruik funksie en verkry waarde
                                
                                //druk afvoer soos versoek
                                lbAfvoer.Items.Add("Stay Charges: " + verblyf.ToString("c"));
                                lbAfvoer.Items.Add("Miscellaneous Charges: " + extras.ToString("c"));
                                lbAfvoer.Items.Add("Total Bill: " + total.ToString("c"));
                            }
                            else
                            {//vertoon fout boodskap en fokus op betrokke textBox
                                MessageBox.Show("Invalid Input!");
                                tbMaR.Focus();
                            }
                        }
                        else
                        {//vertoon fout boodskap en fokus op betrokke textBox
                            MessageBox.Show("Invalid Input!");
                            tbRental.Focus();
                        }
                    }
                    else
                    {//vertoon fout boodskap en fokus op betrokke textBox
                        MessageBox.Show("Invalid Input!");
                        tbTreat.Focus();
                    }
                }
                else
                {//vertoon fout boodskap en fokus op betrokke textBox
                    MessageBox.Show("Invalid Input!");
                    tbRestaurant.Focus();
                }
            }
            else
            {//vertoon fout boodskap en fokus op betrokke textBox
                MessageBox.Show("Invalid Input!");
                tbStay.Focus();
            }
        }
        
        private double CalcStayCharges(int stay)
        {// Verklaar veranderlike
            double total;
            //bereken waarde wat terug gestuur moet word
            total = stay * 550;
            //stuur waarde terug
            return total;
        }

        private double CalcMiscCharges(double kos,double treat,double rent,double med)
        {//verklaar veranderlike
            double total;
            //bereken waarde wat terug gestuur moet word
            total = kos + treat + rent + med;
            //stuur waarde terug
            return total;
        }

        private double CalcTotalCharges(double verblyf, double extras)
        {//verklaar veranderlike
            double total;
            //bereken waarde wat terug gestuur moet word
            total = verblyf + extras;
            //stuur waarde terug
            return total;
        }

    }
}

        