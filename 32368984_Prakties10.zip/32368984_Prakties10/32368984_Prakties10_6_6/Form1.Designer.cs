﻿namespace _32368984_Prakties10_6_6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbStay = new System.Windows.Forms.TextBox();
            this.tbRestaurant = new System.Windows.Forms.TextBox();
            this.tbTreat = new System.Windows.Forms.TextBox();
            this.tbRental = new System.Windows.Forms.TextBox();
            this.tbMaR = new System.Windows.Forms.TextBox();
            this.btnCal = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblStay = new System.Windows.Forms.Label();
            this.lblRestaurant = new System.Windows.Forms.Label();
            this.lblTreat = new System.Windows.Forms.Label();
            this.lblRental = new System.Windows.Forms.Label();
            this.lblMaR = new System.Windows.Forms.Label();
            this.lbAfvoer = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // tbStay
            // 
            this.tbStay.Location = new System.Drawing.Point(239, 26);
            this.tbStay.Name = "tbStay";
            this.tbStay.Size = new System.Drawing.Size(99, 20);
            this.tbStay.TabIndex = 0;
            // 
            // tbRestaurant
            // 
            this.tbRestaurant.Location = new System.Drawing.Point(239, 64);
            this.tbRestaurant.Name = "tbRestaurant";
            this.tbRestaurant.Size = new System.Drawing.Size(99, 20);
            this.tbRestaurant.TabIndex = 1;
            // 
            // tbTreat
            // 
            this.tbTreat.Location = new System.Drawing.Point(239, 105);
            this.tbTreat.Name = "tbTreat";
            this.tbTreat.Size = new System.Drawing.Size(99, 20);
            this.tbTreat.TabIndex = 2;
            // 
            // tbRental
            // 
            this.tbRental.Location = new System.Drawing.Point(239, 144);
            this.tbRental.Name = "tbRental";
            this.tbRental.Size = new System.Drawing.Size(99, 20);
            this.tbRental.TabIndex = 3;
            // 
            // tbMaR
            // 
            this.tbMaR.Location = new System.Drawing.Point(239, 181);
            this.tbMaR.Name = "tbMaR";
            this.tbMaR.Size = new System.Drawing.Size(99, 20);
            this.tbMaR.TabIndex = 4;
            // 
            // btnCal
            // 
            this.btnCal.Location = new System.Drawing.Point(30, 218);
            this.btnCal.Name = "btnCal";
            this.btnCal.Size = new System.Drawing.Size(162, 28);
            this.btnCal.TabIndex = 5;
            this.btnCal.Text = "Calculate Total Charges";
            this.btnCal.UseVisualStyleBackColor = true;
            this.btnCal.Click += new System.EventHandler(this.btnCal_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(231, 218);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(96, 28);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblStay
            // 
            this.lblStay.AutoSize = true;
            this.lblStay.Location = new System.Drawing.Point(27, 29);
            this.lblStay.Name = "lblStay";
            this.lblStay.Size = new System.Drawing.Size(117, 13);
            this.lblStay.TabIndex = 7;
            this.lblStay.Text = "No. of Days Stayed";
            // 
            // lblRestaurant
            // 
            this.lblRestaurant.AutoSize = true;
            this.lblRestaurant.Location = new System.Drawing.Point(27, 67);
            this.lblRestaurant.Name = "lblRestaurant";
            this.lblRestaurant.Size = new System.Drawing.Size(202, 13);
            this.lblRestaurant.TabIndex = 8;
            this.lblRestaurant.Text = "Restaurant Charges including VAT";
            // 
            // lblTreat
            // 
            this.lblTreat.AutoSize = true;
            this.lblTreat.Location = new System.Drawing.Point(27, 108);
            this.lblTreat.Name = "lblTreat";
            this.lblTreat.Size = new System.Drawing.Size(206, 13);
            this.lblTreat.TabIndex = 9;
            this.lblTreat.Text = "Spa and Health Treatment Charges";
            // 
            // lblRental
            // 
            this.lblRental.AutoSize = true;
            this.lblRental.Location = new System.Drawing.Point(28, 147);
            this.lblRental.Name = "lblRental";
            this.lblRental.Size = new System.Drawing.Size(136, 13);
            this.lblRental.TabIndex = 10;
            this.lblRental.Text = "Charges for Car Rental";
            // 
            // lblMaR
            // 
            this.lblMaR.AutoSize = true;
            this.lblMaR.Location = new System.Drawing.Point(27, 184);
            this.lblMaR.Name = "lblMaR";
            this.lblMaR.Size = new System.Drawing.Size(197, 13);
            this.lblMaR.TabIndex = 11;
            this.lblMaR.Text = "Medication and Rehabilitation Bill";
            // 
            // lbAfvoer
            // 
            this.lbAfvoer.FormattingEnabled = true;
            this.lbAfvoer.Location = new System.Drawing.Point(30, 262);
            this.lbAfvoer.Name = "lbAfvoer";
            this.lbAfvoer.Size = new System.Drawing.Size(297, 121);
            this.lbAfvoer.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(367, 405);
            this.Controls.Add(this.lbAfvoer);
            this.Controls.Add(this.lblMaR);
            this.Controls.Add(this.lblRental);
            this.Controls.Add(this.lblTreat);
            this.Controls.Add(this.lblRestaurant);
            this.Controls.Add(this.lblStay);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnCal);
            this.Controls.Add(this.tbMaR);
            this.Controls.Add(this.tbRental);
            this.Controls.Add(this.tbTreat);
            this.Controls.Add(this.tbRestaurant);
            this.Controls.Add(this.tbStay);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Resort Charges";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbStay;
        private System.Windows.Forms.TextBox tbRestaurant;
        private System.Windows.Forms.TextBox tbTreat;
        private System.Windows.Forms.TextBox tbRental;
        private System.Windows.Forms.TextBox tbMaR;
        private System.Windows.Forms.Button btnCal;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblStay;
        private System.Windows.Forms.Label lblRestaurant;
        private System.Windows.Forms.Label lblTreat;
        private System.Windows.Forms.Label lblRental;
        private System.Windows.Forms.Label lblMaR;
        private System.Windows.Forms.ListBox lbAfvoer;
    }
}

