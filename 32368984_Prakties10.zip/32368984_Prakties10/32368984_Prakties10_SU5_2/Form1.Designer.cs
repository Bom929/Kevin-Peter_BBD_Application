﻿namespace _32368984_Prakties9_SU5_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbAfvoer = new System.Windows.Forms.ListBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.lblMark1 = new System.Windows.Forms.Label();
            this.lblMark2 = new System.Windows.Forms.Label();
            this.lblMark3 = new System.Windows.Forms.Label();
            this.tbMark1 = new System.Windows.Forms.TextBox();
            this.tbMark2 = new System.Windows.Forms.TextBox();
            this.tbMark3 = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lbTipe = new System.Windows.Forms.ListBox();
            this.cbPunte = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lbAfvoer
            // 
            this.lbAfvoer.FormattingEnabled = true;
            this.lbAfvoer.ItemHeight = 15;
            this.lbAfvoer.Location = new System.Drawing.Point(21, 8);
            this.lbAfvoer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lbAfvoer.Name = "lbAfvoer";
            this.lbAfvoer.Size = new System.Drawing.Size(315, 274);
            this.lbAfvoer.TabIndex = 20;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // lblMark1
            // 
            this.lblMark1.AutoSize = true;
            this.lblMark1.Location = new System.Drawing.Point(348, 13);
            this.lblMark1.Name = "lblMark1";
            this.lblMark1.Size = new System.Drawing.Size(151, 15);
            this.lblMark1.TabIndex = 2;
            this.lblMark1.Text = "Enter the First Presentage:";
            // 
            // lblMark2
            // 
            this.lblMark2.AutoSize = true;
            this.lblMark2.Location = new System.Drawing.Point(348, 41);
            this.lblMark2.Name = "lblMark2";
            this.lblMark2.Size = new System.Drawing.Size(170, 15);
            this.lblMark2.TabIndex = 3;
            this.lblMark2.Text = "Enter the Second Presentage:";
            // 
            // lblMark3
            // 
            this.lblMark3.AutoSize = true;
            this.lblMark3.Location = new System.Drawing.Point(348, 73);
            this.lblMark3.Name = "lblMark3";
            this.lblMark3.Size = new System.Drawing.Size(156, 15);
            this.lblMark3.TabIndex = 4;
            this.lblMark3.Text = "Enter the Third Presentage:";
            // 
            // tbMark1
            // 
            this.tbMark1.Location = new System.Drawing.Point(528, 10);
            this.tbMark1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbMark1.Name = "tbMark1";
            this.tbMark1.Size = new System.Drawing.Size(116, 21);
            this.tbMark1.TabIndex = 0;
            // 
            // tbMark2
            // 
            this.tbMark2.Location = new System.Drawing.Point(529, 39);
            this.tbMark2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbMark2.Name = "tbMark2";
            this.tbMark2.Size = new System.Drawing.Size(116, 21);
            this.tbMark2.TabIndex = 2;
            // 
            // tbMark3
            // 
            this.tbMark3.Location = new System.Drawing.Point(529, 70);
            this.tbMark3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbMark3.Name = "tbMark3";
            this.tbMark3.Size = new System.Drawing.Size(116, 21);
            this.tbMark3.TabIndex = 3;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(352, 212);
            this.btnCalculate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(87, 26);
            this.btnCalculate.TabIndex = 5;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(556, 212);
            this.btnSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(87, 26);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lbTipe
            // 
            this.lbTipe.FormattingEnabled = true;
            this.lbTipe.ItemHeight = 15;
            this.lbTipe.Items.AddRange(new object[] {
            "Class Tests",
            "Exams",
            "Assignments"});
            this.lbTipe.Location = new System.Drawing.Point(351, 120);
            this.lbTipe.Name = "lbTipe";
            this.lbTipe.Size = new System.Drawing.Size(120, 64);
            this.lbTipe.TabIndex = 21;
            // 
            // cbPunte
            // 
            this.cbPunte.AutoSize = true;
            this.cbPunte.Location = new System.Drawing.Point(351, 95);
            this.cbPunte.Name = "cbPunte";
            this.cbPunte.Size = new System.Drawing.Size(94, 19);
            this.cbPunte.TabIndex = 22;
            this.cbPunte.Text = "Exstra punte";
            this.cbPunte.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(730, 291);
            this.Controls.Add(this.cbPunte);
            this.Controls.Add(this.lbTipe);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.tbMark3);
            this.Controls.Add(this.tbMark2);
            this.Controls.Add(this.tbMark1);
            this.Controls.Add(this.lblMark3);
            this.Controls.Add(this.lblMark2);
            this.Controls.Add(this.lblMark1);
            this.Controls.Add(this.lbAfvoer);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Save Marks";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbAfvoer;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label lblMark1;
        private System.Windows.Forms.Label lblMark2;
        private System.Windows.Forms.Label lblMark3;
        private System.Windows.Forms.TextBox tbMark1;
        private System.Windows.Forms.TextBox tbMark2;
        private System.Windows.Forms.TextBox tbMark3;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ListBox lbTipe;
        private System.Windows.Forms.CheckBox cbPunte;
    }
}

