﻿//Kevin-Peter Naude     32368984
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _32368984_Prakties9_SU5_1
{
    public partial class Form1 : Form
    {
        private double mark1, mark2, mark3, sum;//verklaar globale veranderlikes

        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {   //maak teksBokse skoon en ook list boks
            tbMark1.Text = "";
            tbMark2.Text = "";
            tbMark3.Text = "";
            lbAfvoer.Items.Clear();
            //fokus op eerste textBox
            tbMark1.Focus();
            //deaktifeer save button
            btnSave.Enabled = false;
            //aktifeer calculate button
            btnCalculate.Enabled = true;
        }

        private double SomUit100(double punt1, double punt2, double punt3)
        {
            double som;//verklaar veranderlikes
            som = punt1 + punt2 + punt3;//tel die waardes op
            som = som / 3;//kry die persentasie
            return som;//gee waarde terug
        }

        private string TipeToets(string kies, ref double punt1)
        {
            string test = "";
            if (cbPunte.Checked == true)
            {//verkry tipe toets en verkry ekstra punte  
                switch (kies)
                {
                    case "0":
                        {
                            test = "Class Test";
                            punt1 += 5;
                            break;
                        }

                    case "1":
                        {
                            test = "Exams";
                            punt1 += 2;
                            break;
                        }

                    case "2":
                        {
                            test = "Assignment";
                            punt1 += 8;
                            break;
                        }

                    default:
                        {
                            test = "Marks";
                            punt1 += 1;
                            break;
                        }
                }
            }
            else if (cbPunte.Checked == false)
            {//verkry tipe toets
                switch (kies)
                {
                    case "0":
                        {
                            test = "Class Test";
                            break;
                        }

                    case "1":
                        {
                            test = "Exams";
                            break;
                        }

                    case "2":
                        {
                            test = "Assignment";
                            break;
                        }
                    default:
                        {
                            test = "Marks";
                            break;
                        }
                }
                
            }
            return test;//gee waarde terug
        }

         private void printMarks(double punt1, double punt2, double punt3, double som, string tipe)
        {
            lbAfvoer.Items.Add(tipe);//vertoon tipe toets
            lbAfvoer.Items.Add("Mark 1:\t" + punt1.ToString("n2"));//vertoon eerste punt
            lbAfvoer.Items.Add("Mark 2:\t" + punt2.ToString("n2"));//vertoon tweede punt
            lbAfvoer.Items.Add("Mark 3:\t" + punt3.ToString("n2"));//vertoon derde punt
            lbAfvoer.Items.Add("Sum of the marks:\t" + som.ToString("n2") + " %.");//vertoon die totaal van die 3 punte
        }

        private void Mark1In(out double punt1)
        {
            double.TryParse(tbMark1.Text, out punt1);//verkry die eerste waarde
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {

            Mark1In(out mark1);//gee veranderlike waarde
           
                if(double.TryParse(tbMark2.Text, out mark2))//gee veranderlike waarde
                {
                    if(double.TryParse(tbMark3.Text, out mark3))//gee veranderlike waarde
                    {
                        string tipe = lbTipe.SelectedIndex.ToString();//gebruik funksie
                        string toets = TipeToets(tipe, ref mark1);//gebruik funksie
                        sum = SomUit100(mark1, mark2, mark3);//gebruik funksie
                        printMarks(mark1, mark2, mark3,sum, toets);  //gebruik funksie
                    }
                    else
                    {
                        MessageBox.Show("Invalid Input");//fout boodskap
                        tbMark3.Focus();//fokus op derde punt
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Input");//fout boodskap
                    tbMark2.Focus();// fokus op tweede punt
                }
           
            btnSave.Enabled = true;//aktifeer butten
            btnCalculate.Enabled = false;//deaktifeer button
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            
            
            saveFileDialog1.ShowDialog();//vertoon save dailog
            if(saveFileDialog1.ShowDialog() == DialogResult.OK)//
            {
                sum = mark1 + mark2 + mark3;//verkry die sum
                save(mark1, mark2, mark3, sum);//gebruik funksie
                MessageBox.Show("Saved to Text File");//vertoon boodskap
                btnCalculate.Enabled = true;//heraktifeer button

            }
            else if(saveFileDialog1.ShowDialog() == DialogResult.Cancel)
            {
                MessageBox.Show("Not saved!");//vertoon fout boodskap
            }
        }

        private void save(double punt1, double punt2, double punt3, double som)
        {
            StreamWriter output;

            output = File.CreateText(saveFileDialog1.FileName);
            output.WriteLine("Mark 1:\t" + punt1.ToString("n2"));//skryf na tekslêer
            output.WriteLine("Mark 2:\t" + punt2.ToString("n2"));//skryf na tekslêer
            output.WriteLine("Mark 3:\t" + punt3.ToString("n2"));//skryf na tekslêer
            output.WriteLine("Sum total:\t" + som.ToString("n2") +" %." );//skryf na tekslêer
            output.Close();//maak teks toe
        }
    }
}
