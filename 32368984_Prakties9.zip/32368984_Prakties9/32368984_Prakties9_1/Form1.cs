﻿//Kevin-Peter Naude     32368984
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _32368984_Prakties9_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();//maak program toe
        }

        private void CalculateDisplayCommission(double sales, double persentasie)
        {
            double komusie;//verklaar veranderlike

            komusie = sales * persentasie;//verkry die komusie bedrag

            lblAfvoer.Text = komusie.ToString("C");//vertoon die komusie bedrag
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {//verklaar veranderlikes
            double sales, persentasie;
            //kyk of die gebruiker die regtee data tipe in lees+
            if(double.TryParse(tbSales.Text, out sales))
            {//kyk of die gebruiker die regte data tipe inlees
                if(double.TryParse(tbComusion.Text, out persentasie))
                {
                    persentasie = persentasie / 100;//verkry die persentasie getal vir die funksie

                    CalculateDisplayCommission(sales, persentasie);//gebruik die funksie 
                }
                else
                {
                    MessageBox.Show("Invalid Input!");//fout boodskap
                    tbComusion.Focus();//fokus op die textBox van komusie persentasie
                }
            }
            else
            {
                MessageBox.Show("Invalid Input!");//fout boodskap
                tbSales.Focus();//fokus op die textBox van verkope
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {//maak die textBoxes skoon en fokus op die korekte een
            tbSales.Text = "";
            tbComusion.Text = "";
            tbSales.Focus();
            //maak die label vir afvoer skoon
            lblAfvoer.Text = "";
        }
    }
}
