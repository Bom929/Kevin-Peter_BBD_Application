﻿namespace _32368984_Prakties9_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblRevenue = new System.Windows.Forms.Label();
            this.lblPresentage = new System.Windows.Forms.Label();
            this.lblEarned = new System.Windows.Forms.Label();
            this.lblAfvoer = new System.Windows.Forms.Label();
            this.tbSales = new System.Windows.Forms.TextBox();
            this.tbComusion = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(221, 166);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(118, 47);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(54, 166);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(118, 47);
            this.btnCalculate.TabIndex = 3;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // lblRevenue
            // 
            this.lblRevenue.AutoSize = true;
            this.lblRevenue.Location = new System.Drawing.Point(12, 31);
            this.lblRevenue.Name = "lblRevenue";
            this.lblRevenue.Size = new System.Drawing.Size(97, 15);
            this.lblRevenue.TabIndex = 2;
            this.lblRevenue.Text = "Revemue Sale:  ";
            // 
            // lblPresentage
            // 
            this.lblPresentage.AutoSize = true;
            this.lblPresentage.Location = new System.Drawing.Point(24, 74);
            this.lblPresentage.Name = "lblPresentage";
            this.lblPresentage.Size = new System.Drawing.Size(148, 15);
            this.lblPresentage.TabIndex = 3;
            this.lblPresentage.Text = "Commission Percentage: ";
            // 
            // lblEarned
            // 
            this.lblEarned.AutoSize = true;
            this.lblEarned.Location = new System.Drawing.Point(38, 115);
            this.lblEarned.Name = "lblEarned";
            this.lblEarned.Size = new System.Drawing.Size(122, 15);
            this.lblEarned.TabIndex = 4;
            this.lblEarned.Text = "Earned Commission:";
            // 
            // lblAfvoer
            // 
            this.lblAfvoer.AutoSize = true;
            this.lblAfvoer.Location = new System.Drawing.Point(200, 115);
            this.lblAfvoer.Name = "lblAfvoer";
            this.lblAfvoer.Size = new System.Drawing.Size(40, 15);
            this.lblAfvoer.TabIndex = 5;
            this.lblAfvoer.Text = "Afveor";
            // 
            // tbSales
            // 
            this.tbSales.Location = new System.Drawing.Point(133, 28);
            this.tbSales.Name = "tbSales";
            this.tbSales.Size = new System.Drawing.Size(206, 21);
            this.tbSales.TabIndex = 0;
            // 
            // tbComusion
            // 
            this.tbComusion.Location = new System.Drawing.Point(235, 71);
            this.tbComusion.Name = "tbComusion";
            this.tbComusion.Size = new System.Drawing.Size(104, 21);
            this.tbComusion.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 309);
            this.Controls.Add(this.tbComusion);
            this.Controls.Add(this.tbSales);
            this.Controls.Add(this.lblAfvoer);
            this.Controls.Add(this.lblEarned);
            this.Controls.Add(this.lblPresentage);
            this.Controls.Add(this.lblRevenue);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.btnExit);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblRevenue;
        private System.Windows.Forms.Label lblPresentage;
        private System.Windows.Forms.Label lblEarned;
        private System.Windows.Forms.Label lblAfvoer;
        private System.Windows.Forms.TextBox tbSales;
        private System.Windows.Forms.TextBox tbComusion;
    }
}

