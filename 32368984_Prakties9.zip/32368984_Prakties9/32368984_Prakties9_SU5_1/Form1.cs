﻿//Kevin-Peter Naude     32368984
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _32368984_Prakties9_SU5_1
{
    public partial class Form1 : Form
    {
        private double mark1, mark2, mark3, sum;//verklaar globale veranderlikes

        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {   //maak teksBokse skoon en ook list boks
            tbMark1.Text = "";
            tbMark2.Text = "";
            tbMark3.Text = "";
            lbAfvoer.Items.Clear();
            //fokus op eerste textBox
            tbMark1.Focus();
            //deaktifeer save button
            btnSave.Enabled = false;
            //aktifeer calculate button
            btnCalculate.Enabled = true;
        }

       private void printMarks(double punt1, double punt2, double punt3)
        {//verklaar veranderlikes en geee waardes
            double som;
            bool cToets, eksamen, assesering;
            cToets = rbtntoets.Checked;
            eksamen = rbtnEksamen.Checked;
            assesering = rbtnAssianment.Checked;

            som = punt1 + punt2 + punt3;//tel die waardes op
            lbAfvoer.Items.Clear();//maak die list boks skoon
            if(cToets)
            {
                lbAfvoer.Items.Add("Class Test Makrks");//afvoer
            }
            else if(eksamen)
            {
                lbAfvoer.Items.Add("Exam Makrks");//afvoer
            }
            else if (assesering)
            {
                lbAfvoer.Items.Add("Assignment Makrks");//afvoer
            }
            else
            {
                lbAfvoer.Items.Add("Test Makrks");//afvoer
            }

            lbAfvoer.Items.Add("Mark 1:\t" + punt1.ToString("n2"));//vertoon eerste punt
            lbAfvoer.Items.Add("Mark 2:\t" + punt2.ToString("n2"));//vertoon tweede punt
            lbAfvoer.Items.Add("Mark 3:\t" + punt3.ToString("n2"));//vertoon derde punt
            lbAfvoer.Items.Add("Sum of the marks:\t" + som.ToString("n2") + " / 300.");//vertoon die totaal van die 3 punte
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            
            if(double.TryParse(tbMark1.Text, out mark1))//gee veranderlike waarde
            {
                if(double.TryParse(tbMark2.Text, out mark2))//gee veranderlike waarde
                {
                    if(double.TryParse(tbMark3.Text, out mark3))//gee veranderlike waarde
                    {
                        printMarks(mark1, mark2, mark3);  
                    }
                    else
                    {
                        MessageBox.Show("Invalid Input");//fout boodskap
                        tbMark3.Focus();//fokus op derde punt
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Input");//fout boodskap
                    tbMark2.Focus();// fokus op tweede punt
                }
            }
            else
            {
                MessageBox.Show("Invalid Input");//fout boodskap
                tbMark1.Focus();//fokus op eerste punt
            }
            btnSave.Enabled = true;//aktifeer butten
            btnCalculate.Enabled = false;//deaktifeer button
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            
            
            saveFileDialog1.ShowDialog();//vertoon save dailog
            if(saveFileDialog1.ShowDialog() == DialogResult.OK)//
            {
                sum = mark1 + mark2 + mark3;//verkry die sum
                save(mark1, mark2, mark3, sum);//gebruik funksie
                MessageBox.Show("Saved to Text File");//vertoon boodskap
                btnCalculate.Enabled = true;//heraktifeer button

            }
            else if(saveFileDialog1.ShowDialog() == DialogResult.Cancel)
            {
                MessageBox.Show("Not saved!");//vertoon fout boodskap
            }
        }

        private void save(double punt1, double punt2, double punt3, double som)
        {
            StreamWriter output;

            output = File.CreateText(saveFileDialog1.FileName);
            output.WriteLine("Mark 1:\t" + punt1.ToString("n2"));//skryf na tekslêer
            output.WriteLine("Mark 2:\t" + punt2.ToString("n2"));//skryf na tekslêer
            output.WriteLine("Mark 3:\t" + punt3.ToString("n2"));//skryf na tekslêer
            output.WriteLine("Sum total:\t" + som.ToString("n2") +" / 300." );//skryf na tekslêer
            output.Close();//maak teks toe
        }
    }
}
