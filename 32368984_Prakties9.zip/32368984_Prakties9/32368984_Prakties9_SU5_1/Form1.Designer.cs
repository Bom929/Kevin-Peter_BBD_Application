﻿namespace _32368984_Prakties9_SU5_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbAfvoer = new System.Windows.Forms.ListBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.lblMark1 = new System.Windows.Forms.Label();
            this.lblMark2 = new System.Windows.Forms.Label();
            this.lblMark3 = new System.Windows.Forms.Label();
            this.tbMark1 = new System.Windows.Forms.TextBox();
            this.tbMark2 = new System.Windows.Forms.TextBox();
            this.tbMark3 = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.rbtntoets = new System.Windows.Forms.RadioButton();
            this.rbtnEksamen = new System.Windows.Forms.RadioButton();
            this.rbtnAssianment = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbAfvoer
            // 
            this.lbAfvoer.FormattingEnabled = true;
            this.lbAfvoer.ItemHeight = 20;
            this.lbAfvoer.Location = new System.Drawing.Point(27, 10);
            this.lbAfvoer.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lbAfvoer.Name = "lbAfvoer";
            this.lbAfvoer.Size = new System.Drawing.Size(404, 364);
            this.lbAfvoer.TabIndex = 20;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // lblMark1
            // 
            this.lblMark1.AutoSize = true;
            this.lblMark1.Location = new System.Drawing.Point(448, 17);
            this.lblMark1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMark1.Name = "lblMark1";
            this.lblMark1.Size = new System.Drawing.Size(200, 20);
            this.lblMark1.TabIndex = 2;
            this.lblMark1.Text = "Enter the First Presentage:";
            // 
            // lblMark2
            // 
            this.lblMark2.AutoSize = true;
            this.lblMark2.Location = new System.Drawing.Point(448, 55);
            this.lblMark2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMark2.Name = "lblMark2";
            this.lblMark2.Size = new System.Drawing.Size(224, 20);
            this.lblMark2.TabIndex = 3;
            this.lblMark2.Text = "Enter the Second Presentage:";
            // 
            // lblMark3
            // 
            this.lblMark3.AutoSize = true;
            this.lblMark3.Location = new System.Drawing.Point(448, 97);
            this.lblMark3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMark3.Name = "lblMark3";
            this.lblMark3.Size = new System.Drawing.Size(204, 20);
            this.lblMark3.TabIndex = 4;
            this.lblMark3.Text = "Enter the Third Presentage:";
            // 
            // tbMark1
            // 
            this.tbMark1.Location = new System.Drawing.Point(679, 14);
            this.tbMark1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbMark1.Name = "tbMark1";
            this.tbMark1.Size = new System.Drawing.Size(148, 26);
            this.tbMark1.TabIndex = 0;
            // 
            // tbMark2
            // 
            this.tbMark2.Location = new System.Drawing.Point(680, 52);
            this.tbMark2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbMark2.Name = "tbMark2";
            this.tbMark2.Size = new System.Drawing.Size(148, 26);
            this.tbMark2.TabIndex = 2;
            // 
            // tbMark3
            // 
            this.tbMark3.Location = new System.Drawing.Point(680, 94);
            this.tbMark3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tbMark3.Name = "tbMark3";
            this.tbMark3.Size = new System.Drawing.Size(148, 26);
            this.tbMark3.TabIndex = 3;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(452, 283);
            this.btnCalculate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(112, 35);
            this.btnCalculate.TabIndex = 5;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(715, 283);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(112, 35);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // rbtntoets
            // 
            this.rbtntoets.AutoSize = true;
            this.rbtntoets.Location = new System.Drawing.Point(6, 25);
            this.rbtntoets.Name = "rbtntoets";
            this.rbtntoets.Size = new System.Drawing.Size(109, 24);
            this.rbtntoets.TabIndex = 0;
            this.rbtntoets.TabStop = true;
            this.rbtntoets.Text = "Class Tests";
            this.rbtntoets.UseVisualStyleBackColor = true;
            // 
            // rbtnEksamen
            // 
            this.rbtnEksamen.AutoSize = true;
            this.rbtnEksamen.Location = new System.Drawing.Point(6, 55);
            this.rbtnEksamen.Name = "rbtnEksamen";
            this.rbtnEksamen.Size = new System.Drawing.Size(75, 24);
            this.rbtnEksamen.TabIndex = 1;
            this.rbtnEksamen.TabStop = true;
            this.rbtnEksamen.Text = "Exams";
            this.rbtnEksamen.UseVisualStyleBackColor = true;
            // 
            // rbtnAssianment
            // 
            this.rbtnAssianment.AutoSize = true;
            this.rbtnAssianment.Location = new System.Drawing.Point(6, 85);
            this.rbtnAssianment.Name = "rbtnAssianment";
            this.rbtnAssianment.Size = new System.Drawing.Size(119, 24);
            this.rbtnAssianment.TabIndex = 2;
            this.rbtnAssianment.TabStop = true;
            this.rbtnAssianment.Text = "Assignments";
            this.rbtnAssianment.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbtnAssianment);
            this.groupBox1.Controls.Add(this.rbtntoets);
            this.groupBox1.Controls.Add(this.rbtnEksamen);
            this.groupBox1.Location = new System.Drawing.Point(452, 134);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(150, 126);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tipe of marks";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(939, 388);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.tbMark3);
            this.Controls.Add(this.tbMark2);
            this.Controls.Add(this.tbMark1);
            this.Controls.Add(this.lblMark3);
            this.Controls.Add(this.lblMark2);
            this.Controls.Add(this.lblMark1);
            this.Controls.Add(this.lbAfvoer);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Save Marks";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbAfvoer;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Label lblMark1;
        private System.Windows.Forms.Label lblMark2;
        private System.Windows.Forms.Label lblMark3;
        private System.Windows.Forms.TextBox tbMark1;
        private System.Windows.Forms.TextBox tbMark2;
        private System.Windows.Forms.TextBox tbMark3;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.RadioButton rbtntoets;
        private System.Windows.Forms.RadioButton rbtnEksamen;
        private System.Windows.Forms.RadioButton rbtnAssianment;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

