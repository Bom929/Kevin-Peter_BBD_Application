﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CMPG_223_Systems_Program_Groep2
{
    class Bookings
    {
        // Sql variables
        private SqlConnection Con = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;

        // Private Variables
        private DateTime teeTime;
        private int quantityOfPlayers;
        private int quantityOfHoles;
        private DateTime teeDate;

        public Bookings()
        {
            this.teeTime = new DateTime();
            this.quantityOfPlayers = 0;
            this.quantityOfHoles = 0;
        }

        public Bookings(string teeTime, string teeDate, int quantityOfPlayers, int quantityOfHoles)
        {
            setTeeTime(teeTime);
            setTeeDate(teeDate);
            setQuantityOfPlayers(quantityOfPlayers);
            setQuantityOfHoles(quantityOfHoles);
        }

        public void setTeeTime(string teeTime)
        {
            try
            {
                this.teeTime = DateTime.Parse(teeTime);
            }
            catch (Exception ex)
            {
                throw new Exception("Time is in the wrong format \n" + ex.ToString());
            }
        }

        public DateTime getTeeTime()
        {
            return teeTime;
        }

        public void setTeeDate(string teeDate)
        {
            try
            {
                this.teeTime = DateTime.Parse(teeDate);
            }
            catch (Exception ex)
            {
                throw new Exception("Date is in the wrong format \n" + ex.ToString());
            }
        }

        public DateTime getTeeDate()
        {
            return teeTime;
        }

        public void setQuantityOfPlayers(int quantityOfPlayers)
        {
            this.quantityOfPlayers = quantityOfPlayers;
        }

        public int getQuantityOfPlayers()
        {
            return quantityOfPlayers;
        }

        public void setQuantityOfHoles(int quantityOfHoles)
        {
            this.quantityOfHoles = quantityOfHoles;
        }

        public int getQuantityOfHoles()
        {
            return quantityOfHoles;
        }

        public String checkPayments(string memberId)
        {
            double payment = 0.0;
            int amountPlayers = 0;
            string member = "";
            double newPayment = 0.0;
            try
            {
                Con.Open();
                SqlCommand Comm = new SqlCommand($"Select MemberID, AmountOfPlayers, GreenFee From Booking WHERE MemberID ='{memberId}'", Con);
                SqlDataReader read;
                read = Comm.ExecuteReader();

                while (read.Read())
                {
                    member = read.GetString(0);
                    payment = double.Parse(read.GetString(1));
                    amountPlayers = (int)read.GetInt64(2);
                }
                Con.Close();

                if (memberId != member)
                {
                    return null;
                }
                else
                {
                    newPayment = payment * amountPlayers;
                    return "There is a payment of R" + newPayment.ToString("{0:C}");
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Unable to see if there is a payment due \n" + ex.ToString(), "Check Payments Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        public Boolean checkSchedule(DateTime TeeDate, DateTime TeeTime)
        {
            try
            {
                Con.Open();

                DateTime teeDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day);
                DateTime teeTime = new DateTime();

                SqlCommand Comm = new SqlCommand($"Select TeeDate, TeeTime From Booking WHERE TeeDate ='{TeeDate}' AND TeeTime = '{TeeTime.ToShortTimeString()}'", Con);
                SqlDataReader read;
                read = Comm.ExecuteReader();

                while (read.Read())
                {
                    teeDate = DateTime.Parse(read.GetString(0));
                    teeTime = DateTime.Parse(read.GetString(1));
                }
                Con.Close();

                if (teeTime.ToShortTimeString() == TeeTime.ToShortTimeString() && teeDate == TeeDate)
                {
                    return false;
                }
                else
                {
                    if (teeTime != TeeTime && teeDate != TeeDate)
                    {
                        return true;
                    }
                    return false;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Unable to see if there is a schedule due \n" + ex.ToString(), "Schedule Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public Boolean makeBooking(string aBooking)
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand(aBooking, Con);
                cmd.ExecuteNonQuery();
                Con.Close();
                return true;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Unable to make a booking \n" + ex.ToString(), "Booking error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public Boolean updateBooking(string uBooking)
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand(uBooking, Con);
                cmd.ExecuteNonQuery();
                Con.Close();
                return true;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Unable to update a booking \n" + ex.ToString(), "Update Booking error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public int getPrimaryKey(string memberId)// for update
        {
            try
            {
                int iId = 0;
                Con.Open();

                SqlCommand Comm = new SqlCommand($"Select ID From Booking WHERE MemberID ='{memberId}'", Con);
                SqlDataReader read;
                read = Comm.ExecuteReader();
                while (read.Read())
                {
                    iId = read.GetInt32(0);
                }
                Con.Close();

                return iId;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Can't locate Primary Key value", "Primary Key Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }
        }

        public Boolean removeBooking(string dBooking)
        {
            try
            {
                Con.Open();
                SqlCommand cmd = new SqlCommand(dBooking, Con);
                cmd.ExecuteNonQuery();
                Con.Close();
                return true;
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Unable to delete a booking \n" + ex.ToString(), "Delete Booking error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        public void showData(DataGridView dgvAfvoer)
        {
            try
            {
                Con.Open();

                SqlCommand comm = new SqlCommand($"Select * FROM Booking", Con);
                adapt = new SqlDataAdapter();
                ds = new DataSet();

                adapt.SelectCommand = comm;//gee command vir die adapter
                adapt.Fill(ds, "Booking");//maak die dataset vol met die inligting in die data adapter

                dgvAfvoer.DataSource = ds;//maak die data source die dataset
                dgvAfvoer.DataMember = "Booking";

                Con.Close();

            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);//vertoon fout boodskap
                Con.Close();//Maak konneksie toe na foutboodskap
            }
        }
    }
}
