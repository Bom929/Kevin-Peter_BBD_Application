﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_223_Systems_Program_Groep2
{
    public partial class Form2 : Form
    {
        //Variables - SQL
        private SqlConnection sqlCon = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;
        private SqlCommand comm;


        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                sqlCon.Open();

                SqlCommand comm = new SqlCommand($"Select MemberID, MemberName, MemberSurname, MemberCell From Member", sqlCon);
                adapt = new SqlDataAdapter();
                ds = new DataSet();

                adapt.SelectCommand = comm;//gee command vir die adapter
                adapt.Fill(ds, "Member");//maak die dataset vol met die inligting in die data adapter

                dataGridView1.DataSource = ds;//maak die data source die dataset
                dataGridView1.DataMember = "Member";

                dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                sqlCon.Close();

            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);//vertoon fout boodskap
                sqlCon.Close();//Maak konneksie toe na foutboodskap
            }
        }

        private void mtbxSearch_TextChanged(object sender, EventArgs e)
        {
            // search datagrid view
            sqlCon.Open();

            string sqlQuery = $"Select MemberID, MemberName, MemberSurname, MemberCell From Member WHERE MemberID LIKE '{mtbxSearch.Text}%'";
            SqlCommand Comm = new SqlCommand(sqlQuery, sqlCon);
            ds = new DataSet();
            adapt = new SqlDataAdapter();

            adapt.SelectCommand = Comm;
            adapt.Fill(ds, "Member");

            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Member";

            // resize columns
            dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;


            sqlCon.Close();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
