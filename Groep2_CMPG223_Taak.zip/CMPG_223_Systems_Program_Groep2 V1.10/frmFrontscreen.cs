﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_223_Systems_Program_Groep2
{
    public partial class frmFrontscreen : Form
    {
        private SqlConnection sqlCon = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;
        private SqlCommand comm;
        private string identefire;

        public frmFrontscreen()
        {
            InitializeComponent();
        }

        private void addMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // show notification about program
        }

        private void removeMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDeleteM dm = new frmDeleteM();
            dm.ShowDialog();
            Member memb = new Member();
            memb.showData(dataGridView1);
        }

        private void addMemberToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmAddMember am = new frmAddMember();
            am.ShowDialog();
            Member memb = new Member();
            memb.showData(dataGridView1);
        }

        private void frmFrontscreen_Load(object sender, EventArgs e)
        {


            identefire = Form1.username;

            if (Form1.bUser == "Admin")
            {
                Member werk = new Member();


                werk.showData(dataGridView1);

            }
            else if (Form1.bUser == "Member")
            {
                addMemberToolStripMenuItem.Enabled = false;
                removeMemberToolStripMenuItem.Enabled = false;
                deleteBookingToolStripMenuItem.Enabled = false;
                staffToolStripMenuItem.Enabled = false;


                try
                {
                    sqlCon.Open();
                    string ss = $"Select * FROM Member WHERE Password = '" + identefire + "' ";
                    SqlCommand comm = new SqlCommand(ss, sqlCon);
                    adapt = new SqlDataAdapter();
                    ds = new DataSet();

                    adapt.SelectCommand = comm;//gee command vir die adapter
                    adapt.Fill(ds, "Member");//maak die dataset vol met die inligting in die data adapter

                    dataGridView1.DataSource = ds;//maak die data source die dataset
                    dataGridView1.DataMember = "Member";

                    dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    dataGridView1.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    dataGridView1.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    dataGridView1.Columns[5].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                    sqlCon.Close();

                }
                catch (SqlException error)
                {
                    MessageBox.Show(error.Message);//vertoon fout boodskap
                    sqlCon.Close();//Maak konneksie toe na foutboodskap
                }
            }

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Visible = false;
        }

        private void frmFrontscreen_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void updateMemberToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUpdateM um = new frmUpdateM();
            um.ShowDialog();

            Member memb = new Member();
            memb.showData(dataGridView1);
        }

        private void addBookingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBookings ba = new frmBookings();
            ba.ShowDialog();
            Bookings book = new Bookings();
            book.showData(dataGridView1);

        }

        private void updateBookingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUpdateB ub = new frmUpdateB();
            ub.ShowDialog();

            Bookings book = new Bookings();
            book.showData(dataGridView1);

        }

        private void deleteBookingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmDeleteBooking dbook = new frmDeleteBooking();

            dbook.ShowDialog();

            Bookings bs = new Bookings();
            bs.showData(dataGridView1);
        }

        private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            identefire = Form1.bUser;
            if(identefire == "Admin")
            {
                frmReport frm = new frmReport();
                frm.ShowDialog();
                
            }
            else
            {
                MessageBox.Show("Admin only", "Admin only", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
