﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_223_Systems_Program_Groep2
{
    public partial class frmUpdateM : Form
    {

        private SqlConnection sqlCon = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;
        private SqlCommand comm;

        public frmUpdateM()
        {
            InitializeComponent();
        }

        private void cancelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string id;
            id = cbMemberID.SelectedItem.ToString();
            string type = "";
            
            if (redCell.Checked)
            {
                type = "MemberCell";
            }
            else if (redEmail.Checked)
            {
                type = "MemberEmail";
            }
            else if (redSurname.Checked)
            {
                type = "MemberSurname";
            }

            string info = textBox1.Text;

            Member memb = new Member();
            string Com = $"UPDATE Member SET " + type + " = '" + info + "' WHERE MemberID = " + id + "  ";

            memb.updateMember(Com);
            frmFrontscreen frm = new frmFrontscreen();

            this.Close();

        }

        private void frmUpdateM_Load(object sender, EventArgs e)
        {
            try
            {
                sqlCon.Open();
                comm = new SqlCommand($"SELECT MemberID From Member", sqlCon);
                SqlDataReader read;
                read = comm.ExecuteReader();

                while (read.Read())
                {
                    cbMemberID.Items.Add(read.GetValue(0));

                }

                sqlCon.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
                sqlCon.Close();
            }
        }

        private void frmUpdateM_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }
    }
}
