﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_223_Systems_Program_Groep2
{
    public partial class frmDeleteBooking : Form
    {

        private SqlConnection sqlCon = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;
        private SqlCommand comm;
        private string id;
        private string bid;
        public frmDeleteBooking()
        {
            InitializeComponent();
        }

        private void frmDeleteBooking_Load(object sender, EventArgs e)
        {
            cbTime.Items.Clear();
            try
            {
                sqlCon.Open();
                comm = new SqlCommand($"SELECT MemberID From Member", sqlCon);
                SqlDataReader read;
                read = comm.ExecuteReader();

                while (read.Read())
                {
                    cbMemberID.Items.Add(read.GetValue(0));

                }

                sqlCon.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
                sqlCon.Close();
            }
        }

        private void cbMemberID_SelectedIndexChanged(object sender, EventArgs e)
        {
            id = cbMemberID.SelectedItem.ToString();
            try
            {
                string str = $"SELECT BookingID From Booking  WHERE MemberID = " + id + " ";
                sqlCon.Open();
                comm = new SqlCommand(str, sqlCon);
                SqlDataReader read;
                read = comm.ExecuteReader();

                while (read.Read())
                {
                    cbTime.Items.Add(read.GetValue(0));
                }
                sqlCon.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
                sqlCon.Close();
            }

            try
            {

                string ss = $"SELECT * From Booking Where MemberID = " + id + " ";
                sqlCon.Open();
                comm = new SqlCommand(ss, sqlCon);
                adapt = new SqlDataAdapter();
                ds = new DataSet();
                adapt.SelectCommand = comm;
                adapt.Fill(ds, "Booking");

                dgvDelete.DataSource = ds;//maak die data source die dataset
                dgvDelete.DataMember = "Booking";

                sqlCon.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
                sqlCon.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            bid = cbTime.SelectedItem.ToString();

            string str = $"Delete From Booking WHERE BookingID = " + bid + "";

            Bookings bs = new Bookings();
            bs.removeBooking(str);

            this.Close();
        }

        private void frmDeleteBooking_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }
    }
}
