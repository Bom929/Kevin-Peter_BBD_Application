﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_223_Systems_Program_Groep2
{
    public partial class frmAddMember : Form
    {
        private static readonly Random getrandom = new Random();

        private readonly SqlConnection sqlCon = new SqlConnection(StringVariables.connectionString);
        private SqlCommand comm;

        public static int GetRandomNumber(int min, int max)
        {
            lock (getrandom) // synchronize
            {
                return getrandom.Next(min, max);
            }
        }

        public frmAddMember()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string nm, van, cell, email, pass, temp, id = "";

            nm = tbName.Text;
            van = tbVan.Text;
            cell = tbCell.Text;
            email = tbEmail.Text;
            pass = "";

            if (nm == "")
            {
                MessageBox.Show("Name can't be empty.");
                tbName.Focus();

            }
            for (int i = 0; i < 2; i++)
            {
                pass += nm[i];

            }
            for (int j = 0; j < 2; j++)
            {
                pass += van[j];

            }

            int passtemp = 0;
            for (int k =0; k<4;k++)
            {
                passtemp = GetRandomNumber(0, 9);
                temp = passtemp.ToString();
                id += temp;
            }

            for (int j = 0; j < 2; j++)
            {
                pass += id[j];
            }

            int mID = 0;

            mID = Int32.Parse(id);

            Member memb = new Member();

            try
            {
                memb.insertMember(nm, van, email, cell, mID, pass);
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }

            this.Close();
        }

        private void frmAddMember_Load(object sender, EventArgs e)
        {//maak alle tb skoon wanneer dat ingevoeg word.
            tbName.Text = "";
            tbVan.Text = "";
            tbEmail.Text = "";
            tbCell.Text = "";
            tbName.Focus();

        }
    }

    
}
