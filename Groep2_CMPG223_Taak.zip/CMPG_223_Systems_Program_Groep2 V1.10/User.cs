﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CMPG_223_Systems_Program_Groep2
{
    public abstract class User
    {
        //SQL Variables
        private SqlConnection Con = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;

        // variables
        private int userId;
        private string emailAddress;
        private int phoneNumber; 

        public User()
        {
            userId = 0;
            emailAddress = "";
            phoneNumber = 0;
        }

        public User(int userId, string emailAddress, int phoneNumber)
        {
            setUserId(userId);
            setEmailAddress(emailAddress);
            setPhoneNumber(phoneNumber);
        }

        public void setUserId(int userId)
        {
            if(userId == 0)
            {
                this.userId = 0;
            }
            else
            {
                this.userId = userId;
            }
        }

        public int getUserId()
        {
            return userId;
        }

        public void setEmailAddress(string emailAddress)
        {
            if (emailAddress.Length == 0)
            {
                this.emailAddress = null;
            }
            else
            {
                this.emailAddress = emailAddress;
            }
        }

        public string getEmailAddress()
        {
            return null;
        }

        public void setPhoneNumber(int phoneNumber)
        {
            this.phoneNumber = phoneNumber;
        }

        public int getPhoneNumber()
        {
            return phoneNumber;
        }

        public abstract Boolean logIn();
        public abstract Boolean logOut();
        
    }
}
