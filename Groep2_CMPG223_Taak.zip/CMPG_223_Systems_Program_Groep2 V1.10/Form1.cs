﻿//32368984 - Kevin-Peter Naudé
//34361634- Marco Mynhardt
//36039357 – Charles Henry Steyn	
				
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CMPG_223_Systems_Program_Groep2
{
    public partial class Form1 : Form
    {

        public static string bUser = "";
        public static string username = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tbUser.Text = "";
            tbPass.Text = "";
            tbUser.Focus();
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            // make password visible
            tbPass.UseSystemPasswordChar = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string User = "Admin";
            string Pass = "admin";
            if (tbUser.Text == User && tbPass.Text == Pass)
            {
                MessageBox.Show("Access Granted", "Login Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                frmFrontscreen newScreen = new frmFrontscreen();
                bUser = cbUser.SelectedItem.ToString();
                username = tbUser.Text;
                newScreen.Show();
                this.Visible = false;
            }
            else
            {
                Login lg = new Login(Name: tbUser.Text, Password: tbPass.Text);
                Boolean test = false;

                test = lg.Compare();

                if (test == false)
                {
                    MessageBox.Show("Incorrect Username or Password", "Login Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("Access Granted", "Login Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    frmFrontscreen newScreen = new frmFrontscreen();
                    bUser = cbUser.SelectedItem.ToString();
                    username = tbPass.Text;
                    newScreen.Show();
                    this.Visible = false;
                }
            }
        }


        private void button2_MouseLeave(object sender, EventArgs e)
        {
            // make password visible
            tbPass.UseSystemPasswordChar = true;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void rbtnStaff_CheckedChanged(object sender, EventArgs e)
        {
            

        }

        private void rbtnMembers_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
