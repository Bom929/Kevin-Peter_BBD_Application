﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_223_Systems_Program_Groep2
{
    public partial class frmReport : Form
    {
        private SqlConnection sqlCon = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;
        private SqlCommand comm;

        public frmReport()
        {
            InitializeComponent();
        }

        private void mtbxSearch_TextChanged(object sender, EventArgs e)
        {
            // search datagrid view
            sqlCon.Open();

            string sqlQuery = $"Select MemberID, TeeDate, TeeTime From Booking WHERE MemberID LIKE '{mtbxSearch.Text}%'";
            SqlCommand Comm = new SqlCommand(sqlQuery, sqlCon);
            ds = new DataSet();
            adapt = new SqlDataAdapter();

            adapt.SelectCommand = Comm;
            adapt.Fill(ds, "Booking");

            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Booking";

            // resize columns
            dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            sqlCon.Close();
        }

        private void frmReport_Load(object sender, EventArgs e)
        {
            try
            {
                sqlCon.Open();

                SqlCommand comm = new SqlCommand($"Select MemberID, TeeDate, TeeTime From Booking", sqlCon);
                adapt = new SqlDataAdapter();
                ds = new DataSet();

                adapt.SelectCommand = comm;//gee command vir die adapter
                adapt.Fill(ds, "Booking");//maak die dataset vol met die inligting in die data adapter

                dataGridView1.DataSource = ds;//maak die data source die dataset
                dataGridView1.DataMember = "Booking";

                dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                sqlCon.Close();

            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);//vertoon fout boodskap
                sqlCon.Close();//Maak konneksie toe na foutboodskap
            }
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.Show();
            this.Visible = false;
        }

        private void frmReport_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void subscriptionReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.Show();
            
        }
    }
}
