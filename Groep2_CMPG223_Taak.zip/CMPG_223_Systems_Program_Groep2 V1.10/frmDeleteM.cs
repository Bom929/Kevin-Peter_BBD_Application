﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_223_Systems_Program_Groep2
{
    public partial class frmDeleteM : Form
    {

        private SqlConnection sqlCon = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;
        private SqlCommand comm;


        public frmDeleteM()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmDeleteM_Load(object sender, EventArgs e)
        {
            try
            {
                sqlCon.Open();
                comm = new SqlCommand($"SELECT MemberID From Member", sqlCon);
                SqlDataReader read;
                read = comm.ExecuteReader();
                
                while(read.Read())
                {
                    cbDelete.Items.Add(read.GetValue(0));
                    
                }

                sqlCon.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
                sqlCon.Close();
            }

            Member memb = new Member();

            memb.showData(dgvAfvoer);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Worker werk = new Worker();

            string id = cbDelete.SelectedItem.ToString();
            werk.deleteMember(Int32.Parse(id));
            werk.showData(dgvAfvoer);
        }

        private void frmDeleteM_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
    }
}
