﻿
namespace CMPG_223_Systems_Program_Groep2
{
    partial class frmUpdateM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cbMemberID = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.redEmail = new System.Windows.Forms.RadioButton();
            this.redCell = new System.Windows.Forms.RadioButton();
            this.redSurname = new System.Windows.Forms.RadioButton();
            this.lblUpdate = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select member ID:";
            // 
            // cbMemberID
            // 
            this.cbMemberID.FormattingEnabled = true;
            this.cbMemberID.Location = new System.Drawing.Point(147, 33);
            this.cbMemberID.Name = "cbMemberID";
            this.cbMemberID.Size = new System.Drawing.Size(121, 21);
            this.cbMemberID.TabIndex = 6;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.redEmail);
            this.groupBox1.Controls.Add(this.redCell);
            this.groupBox1.Controls.Add(this.redSurname);
            this.groupBox1.Location = new System.Drawing.Point(15, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(158, 152);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "What To Update:";
            // 
            // redEmail
            // 
            this.redEmail.AutoSize = true;
            this.redEmail.Location = new System.Drawing.Point(6, 115);
            this.redEmail.Name = "redEmail";
            this.redEmail.Size = new System.Drawing.Size(88, 17);
            this.redEmail.TabIndex = 10;
            this.redEmail.TabStop = true;
            this.redEmail.Text = "Update Email";
            this.redEmail.UseVisualStyleBackColor = true;
            // 
            // redCell
            // 
            this.redCell.AutoSize = true;
            this.redCell.Location = new System.Drawing.Point(6, 74);
            this.redCell.Name = "redCell";
            this.redCell.Size = new System.Drawing.Size(148, 17);
            this.redCell.TabIndex = 9;
            this.redCell.TabStop = true;
            this.redCell.Text = "Update Cellphone number";
            this.redCell.UseVisualStyleBackColor = true;
            // 
            // redSurname
            // 
            this.redSurname.AutoSize = true;
            this.redSurname.Location = new System.Drawing.Point(6, 34);
            this.redSurname.Name = "redSurname";
            this.redSurname.Size = new System.Drawing.Size(105, 17);
            this.redSurname.TabIndex = 8;
            this.redSurname.TabStop = true;
            this.redSurname.Text = "Update Surname";
            this.redSurname.UseVisualStyleBackColor = true;
            // 
            // lblUpdate
            // 
            this.lblUpdate.AutoSize = true;
            this.lblUpdate.Location = new System.Drawing.Point(233, 76);
            this.lblUpdate.Name = "lblUpdate";
            this.lblUpdate.Size = new System.Drawing.Size(132, 13);
            this.lblUpdate.TabIndex = 8;
            this.lblUpdate.Text = "Enter the Updated Details:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(236, 110);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(126, 20);
            this.textBox1.TabIndex = 9;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(236, 184);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(91, 44);
            this.btnUpdate.TabIndex = 10;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(492, 24);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cancelToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // cancelToolStripMenuItem
            // 
            this.cancelToolStripMenuItem.Name = "cancelToolStripMenuItem";
            this.cancelToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.cancelToolStripMenuItem.Text = "Cancel";
            this.cancelToolStripMenuItem.Click += new System.EventHandler(this.cancelToolStripMenuItem_Click);
            // 
            // frmUpdateM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(492, 321);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblUpdate);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbMemberID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmUpdateM";
            this.Text = "Update Member Info";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmUpdateM_FormClosed);
            this.Load += new System.EventHandler(this.frmUpdateM_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbMemberID;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton redEmail;
        private System.Windows.Forms.RadioButton redCell;
        private System.Windows.Forms.RadioButton redSurname;
        private System.Windows.Forms.Label lblUpdate;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelToolStripMenuItem;
    }
}