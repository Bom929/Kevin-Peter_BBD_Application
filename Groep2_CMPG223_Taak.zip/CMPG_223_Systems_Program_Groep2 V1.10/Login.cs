﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CMPG_223_Systems_Program_Groep2
{
    class Login
    {
        // variables
        private string Name;
        private string Password;
        private string dbName;
        private string dbPassword;

        // Sql variables
        private SqlConnection sqlCon = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;

        public Login()
        {
            this.Name = "";
            this.Password = "";
            this.dbName = "";
            this.dbPassword = "";
        }

        public Login(string Name, string Password)
        {
            setName(Name);
            setPassword(Password);
        }

        public void setName(string Name)
        {
            this.Name = Name;
        }

        public void setPassword(string Password)
        {
            this.Password = Password;
        }

        public string getName()
        {
            // validate name
            var lenght = 0;
            lenght = Name.Length;

            if(lenght == 0)
            {
                return null;
            }
            else
            {
                return Name;
            }
        }

        public string getPassword()
        {
            // validate password
            var lenght = 0;
            lenght = Name.Length;

            if (lenght == 0)
            {
                return null;
            }
            else
            {
                return Password;
            }
        }

        public string getDbPassword()
        {
            // get password in DB
            sqlCon.Open();

            SqlCommand comm = new SqlCommand($"SELECT Password FROM Member WHERE Password = '{getPassword()}'", sqlCon);
            SqlDataReader read;
            read = comm.ExecuteReader();

            while (read.Read())
            {
                dbPassword = read.GetString(0);
            }

            sqlCon.Close();
            return dbPassword;
        }

        public string getDbName()
        {
            // get Name in DB
            try
            {
                sqlCon.Open();

                SqlCommand comm = new SqlCommand($"SELECT MemberName FROM Member WHERE MemberName = '{getName()}'", sqlCon);
                SqlDataReader read;
                read = comm.ExecuteReader();

                while (read.Read())
                {
                    dbName = read.GetString(0);
                }

                sqlCon.Close();
                return dbName;
            }
            catch(SqlException Ex)
            {
                return null;
            }
        }

        public Boolean Compare()
        {
            // check if input data compare with DB data
            try
            {
                if(getName() == null || getPassword() == null || getDbName() == null || getDbPassword() == null)
                {
                    return false;
                }
                else
                {
                    if (getPassword() == getPassword() && getDbName() == getName())
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch
            {
                return false;
            }
            
        }
    }
}
