﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_223_Systems_Program_Groep2
{
    public partial class frmBookings : Form
    {
        private SqlConnection sqlCon = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;
        private SqlCommand comm;

        public frmBookings()
        {
            InitializeComponent();
        }

        private void frmBookings_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void frmBookings_Load(object sender, EventArgs e)
        {
            tbxMemberId.Text = "";
            tbxMemberId.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id;
            DateTime date = new DateTime();
            DateTime Dtime = new DateTime();

            if (tbxMemberId.Text.Length == 0)
            {
                MessageBox.Show("PLease enter a member ID", "Empty member ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                id = tbxMemberId.Text;

                if (cbxTime.SelectedItem.ToString().Length == 0)
                {
                    MessageBox.Show("PLease select a Time to play", "Invalid time picked", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    Dtime = DateTime.Parse(cbxTime.SelectedItem.ToString());
                    date = monthCalendar1.SelectionRange.Start;

                    Bookings bs = new Bookings();

                    Boolean bCheck = false;
                    bCheck = bs.checkSchedule(TeeDate: date, TeeTime: Dtime);

                    int amount = int.Parse(cbxAmount.SelectedItem.ToString());
                    double greenFee = 150.0;

                    if (bCheck == true)
                    {
                        Boolean bInsert = false;
                        string squary = $"Insert Into Booking (MemberID, TeeDate, TeeTime, AmountOfPlayers, GreenFee) VALUES('{id}','{date}','{Dtime}','{amount}','{greenFee}')";
                        bInsert = bs.makeBooking(squary);
                        if (bInsert == false)
                        {
                            MessageBox.Show("Data has not been inserted", "Insert Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            MessageBox.Show("Data has been inserted", "Insert Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                    }
                    else
                    {
                        MessageBox.Show("The selected schedule is already booked", "Selected date", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }

            this.Close();
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Please enter you member ID than select amount of players that is going to play. \nSelect a time and date to play to play", "Help", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
