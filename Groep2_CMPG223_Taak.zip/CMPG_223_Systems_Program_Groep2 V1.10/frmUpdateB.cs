﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CMPG_223_Systems_Program_Groep2
{
    public partial class frmUpdateB : Form
    {

        private SqlConnection sqlCon = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;
        private SqlCommand comm;
        private string id;
        private string bid;


        public frmUpdateB()
        {
            InitializeComponent();
        }

        private void cbMemberID_SelectedIndexChanged(object sender, EventArgs e)
        {
            id = cbMemberID.SelectedItem.ToString();
            cbBid.Items.Clear();
            try
            {
                string str = $"SELECT BookingID From Booking  WHERE MemberID = " + id + " ";
                sqlCon.Open();
                comm = new SqlCommand(str, sqlCon);
                SqlDataReader read;
                read = comm.ExecuteReader();

                while (read.Read())
                {
                    cbBid.Items.Add(read.GetValue(0));
                }
                sqlCon.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
                sqlCon.Close();
            }

            try
            {

                string ss = $"SELECT * From Booking Where MemberID = " + id + " ";
                sqlCon.Open();
                comm = new SqlCommand(ss, sqlCon);
                adapt = new SqlDataAdapter();
                ds = new DataSet();
                adapt.SelectCommand = comm;
                adapt.Fill(ds, "Booking");

                dataGridView1.DataSource = ds;//maak die data source die dataset
                dataGridView1.DataMember = "Booking";

                sqlCon.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
                sqlCon.Close();
            }
        }

        private void frmUpdateB_Load(object sender, EventArgs e)
        {
            cbBid.Items.Clear();
            try
            {
                sqlCon.Open();
                comm = new SqlCommand($"SELECT MemberID From Member", sqlCon);
                SqlDataReader read;
                read = comm.ExecuteReader();

                while (read.Read())
                {
                    cbMemberID.Items.Add(read.GetValue(0));

                }

                sqlCon.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
                sqlCon.Close();
            }

            

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            
            
            DateTime date = new DateTime();
            DateTime Dtime = new DateTime();

            if (cbMemberID.Text.Length == 0)
            {
                MessageBox.Show("PLease enter a member ID", "Empty member ID", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                id = cbMemberID.SelectedItem.ToString();

                if (cbTime.SelectedItem.ToString().Length == 0)
                {
                    MessageBox.Show("Please select a Time to play", "Invalid time picked", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {

                    if (DateTime.TryParse(cbTime.SelectedItem.ToString(),out Dtime ) == true)
                    {
                        
                    }
                    else
                    {
                        MessageBox.Show("Please enter correct time.", "Time Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    
                    date = calDate.SelectionRange.Start;

                    Bookings bs = new Bookings();

                    Boolean bCheck = false;
                    bCheck = bs.checkSchedule(TeeDate: date, TeeTime: Dtime);
                    bid = cbBid.SelectedItem.ToString();

                    

                    if (bCheck == true)
                    {
                        Boolean bUpdate = false;
                        string squary = $"UPDATE Booking SET TeeTime = '" + Dtime + "' WHERE MemberID = " + id + " And BookingID = " + bid + "  ";
                        bUpdate = bs.updateBooking(squary);
                        if (bUpdate == false)
                        {
                            MessageBox.Show("Data has not been Updated", "Update Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            MessageBox.Show("Data has been Updated", "Update Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                    }
                    else
                    {
                        MessageBox.Show("The selected schedule is already booked", "Selected date", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }

            this.Close();
        }

        private void frmUpdateB_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }
    }
}
