﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace CMPG_223_Systems_Program_Groep2
{
    class Staff : User
    {
        //SQL Variables
        private SqlConnection Con = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;

        // variables
        private DateTime hoursWorked;
        private DateTime schedule;

        public Staff()
        {
            this.hoursWorked = new DateTime();
            this.schedule = new DateTime();
        }

        public Staff(int userId, string emailAddress, int phoneNumber, DateTime hoursWorked, DateTime schedule)
        {
            // superclass
            this.setUserId(userId);
            this.setEmailAddress(emailAddress);
            this.setPhoneNumber(phoneNumber);

            // Subclass
            setHoursWorked(hoursWorked);
            setSchedule(schedule);

        }

        public void setHoursWorked(DateTime hoursWorked)
        {
            this.hoursWorked = hoursWorked;
        }

        public void setSchedule(DateTime schedule)
        {
            this.schedule = schedule;
        }

        public DateTime getHoursWorked()
        {
            return hoursWorked;
        }

        public DateTime getSchedule()
        {
            return schedule;
        }

        // abstract methods
        public override bool logIn()
        {
            throw new NotImplementedException();
        }

        public override bool logOut()
        {
            throw new NotImplementedException();
        }

        

        // normal methods
        // is nog onseker oor die types
        public Boolean receivePayment()
        {
            return false;
        }

        public void bookingSchedule()
        {
            Bookings makeBooking = new Bookings();
        }

        public Boolean addMember(string addMember)
        {
            return false;
        }

        public Boolean removeMember(string removeMember)
        {
            return false;
        }

        public Boolean updateMember(string updateMember)
        {
            return false;
        }
    }
}