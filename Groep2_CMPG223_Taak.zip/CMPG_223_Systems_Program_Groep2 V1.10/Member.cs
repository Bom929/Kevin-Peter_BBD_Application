﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace CMPG_223_Systems_Program_Groep2
{
    class Member : User
    {
        // variables
        private string Name;
        private string Password;
        private string surname;
        private string email;
        private string cell;

        // Sql variables
        private SqlConnection sqlCon = new SqlConnection(StringVariables.connectionString);
        private DataSet ds;
        private SqlDataAdapter adapt;
        private SqlCommand comm;

        public Member()
        {
            this.Name = "";
            this.Password = "";
            
            this.surname = "";
            
        }

        public Member(int memberID, string Name, string Password, string Surname)
        {
            this.setUserId(memberID);
            this.getEmailAddress();
            this.getPhoneNumber();
            setName(Name);
            setPassword(Password);
            setSurname(Surname);
        }

        public void setName(string Name)
        {
            this.Name = Name;
        }

        public void setSurname(string Surname)
        {
            surname = Surname;
        }

        public void setPassword(string Password)
        {
            this.Password = Password;
        }


        public string getName()
        {
            // validate name
            var lenght = 0;
            lenght = Name.Length;

            if (lenght == 0)
            {
                return null;
            }
            else
            {
                return Name;
            }
        }

        public string getPassword()
        {
            // validate password
            var lenght = 0;
            lenght = Password.Length;

            if (lenght == 0)
            {
                return null;
            }
            else
            {
                return Password;
            }
        }


        
        public void showData(DataGridView dgvAfvoer)
        {
            try
            {
                sqlCon.Open();

                SqlCommand comm = new SqlCommand($"Select * FROM Member", sqlCon);
                adapt = new SqlDataAdapter();
                ds = new DataSet();

                adapt.SelectCommand = comm;//gee command vir die adapter
                adapt.Fill(ds, "Member");//maak die dataset vol met die inligting in die data adapter

                dgvAfvoer.DataSource = ds;//maak die data source die dataset
                dgvAfvoer.DataMember = "Member";

                sqlCon.Close();
                
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);//vertoon fout boodskap
                sqlCon.Close();//Maak konneksie toe na foutboodskap
            }
        }

        public Boolean insertMember(string nm, string van, string epos , string sel, int id, string pass)
        {
            try
            {
                sqlCon.Open();

                SqlCommand comm = new SqlCommand($"INSERT INTO Member( MemberID, MemberName, MemberSurname, MemberEmail, MemberCell, Password) VALUES ({id},'{nm}','{van}','{epos}','{sel}','{pass}')", sqlCon);
                adapt = new SqlDataAdapter();
                adapt.InsertCommand = comm;
                adapt.InsertCommand.ExecuteNonQuery();
                //int i =comm.ExecuteNonQuery();//wys data die query nie 'n sql query is nie

                sqlCon.Close();

                sqlCon.Open();
                comm = new SqlCommand($"INSERT INTO Subscription ( MemberID, DatePaymentDue, AmountDue) VALUES ({id}, '2021/10/31', 1000)", sqlCon);
                adapt = new SqlDataAdapter();
                adapt.InsertCommand = comm;
                adapt.InsertCommand.ExecuteNonQuery();

                sqlCon.Close();
                /*if (i!=0)
                {
                    MessageBox.Show("data saved");
                }*/
                return true;
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);//vertoon fout boodskap
                sqlCon.Close();//Maak konneksie toe na foutboodskap
                return false;
            }
            

        }

        public Boolean updateMember(string Com)
        {

            try
            {
                sqlCon.Open();

                SqlCommand comm = new SqlCommand(Com , sqlCon);

                
                comm.ExecuteNonQuery();

                sqlCon.Close();

                return true;
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);//vertoon fout boodskap
                sqlCon.Close();//Maak konneksie toe na foutboodskap
                return false;
            }

            
        }

        /*public Boolean deleteMember(int id)
        {

            try
            {
                sqlCon.Open();

                SqlCommand comm = new SqlCommand($"Delete From Member WHERE MemberID = {id}", sqlCon);
                comm.ExecuteNonQuery();//wys dat dit nie 'n sql query is wat jy wil uitvoer

                sqlCon.Close();

                return true;
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);//vertoon fout boodskap
                sqlCon.Close();//Maak konneksie toe na foutboodskap
                return false;
            }


        }*/

        public override bool logIn()
        {
            return true;
        }

        public override bool logOut()
        {
            return false;
        }

        
    }
}
